package com.brenise.glassicons

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { Theme { GlassApp() } }
    }
}

@Composable
fun Theme(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    val dark = isSystemInDarkTheme()
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme() else -> lightColorScheme()
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

private val tints = listOf(0xFF7C9CFF, 0xFFFF7CB2, 0xFF7CFFC4, 0xFFFFD27C, 0xFFB07CFF, 0xFFFFFFFF).map { it.toInt() }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GlassApp() {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }

    var global by remember { mutableStateOf(IconStyle()) }
    var universal by remember { mutableStateOf(true) }
    val overrides = remember { mutableStateMapOf<String, IconStyle>() }
    var selected by remember { mutableStateOf<AppItem?>(null) }
    val sel = selected ?: apps.firstOrNull()

    fun styleOf(a: AppItem) = if (universal) global else overrides[a.pkg] ?: global
    val current = sel?.let { styleOf(it) } ?: global
    fun update(n: IconStyle) { if (universal) global = n else sel?.let { overrides[it.pkg] = n } }

    Scaffold(topBar = { CenterAlignedTopAppBar(title = { Text("Glass Icons") }) }) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Adaptive(76.dp),
            modifier = Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (sel != null) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Preview(sel, current)
                        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                            Design.values().forEachIndexed { i, d ->
                                SegmentedButton(
                                    selected = current.design == d,
                                    onClick = { update(current.withDesign(d)) },
                                    shape = SegmentedButtonDefaults.itemShape(i, Design.values().size)
                                ) { Text(d.label) }
                            }
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Same design for all icons", style = MaterialTheme.typography.titleSmall)
                                Text(
                                    if (universal) "Editing every icon" else "Editing ${sel.label} only",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                            Switch(universal, { universal = it })
                        }
                        ElevatedCard(shape = RoundedCornerShape(24.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Param("Corner radius", current.corner, 0f..0.5f) { update(current.copy(corner = it, design = Design.CUSTOM)) }
                                Param("Squircle smoothing", current.smooth, 0f..1f) { update(current.copy(smooth = it, design = Design.CUSTOM)) }
                                Param("Glyph padding", current.padding, 0f..0.3f) { update(current.copy(padding = it)) }
                                Param("Frost", current.frost, 0f..1f) { update(current.copy(frost = it)) }
                                Param("Edge highlight", current.border, 0f..1f) { update(current.copy(border = it)) }
                                Param("Shine", current.shine, 0f..1f) { update(current.copy(shine = it)) }
                                Spacer(Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                    tints.forEach { t ->
                                        Box(
                                            Modifier.size(34.dp).clip(CircleShape).background(Color(t))
                                                .border(if (t == current.tint) 3.dp else 1.dp,
                                                    MaterialTheme.colorScheme.primary.copy(if (t == current.tint) 1f else .3f), CircleShape)
                                                .clickable { update(current.copy(tint = t)) }
                                        )
                                    }
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            FilledTonalButton({ savePng(ctx, GlassRenderer.render(sel.icon, current), sel.label) }, Modifier.weight(1f)) { Text("Save PNG") }
                            Button({ pin(ctx, sel, GlassRenderer.render(sel.icon, current)) }, Modifier.weight(1f)) { Text("Add to home") }
                        }
                        Text("Your apps", style = MaterialTheme.typography.titleMedium)
                    }
                }
            }
            items(apps, key = { it.pkg }) { app ->
                val st = styleOf(app)
                val bmp = remember(app.pkg, st) { GlassRenderer.render(app.icon, st, 192).asImageBitmap() }
                Column(
                    Modifier.clip(RoundedCornerShape(16.dp))
                        .background(if (app.pkg == sel?.pkg) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                        .clickable { selected = app }.padding(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Image(bmp, app.label, Modifier.size(60.dp))
                    Text(app.label, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
fun Preview(app: AppItem, style: IconStyle) {
    val bmp = remember(app.pkg, style) { GlassRenderer.render(app.icon, style, 512).asImageBitmap() }
    Box(
        Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(listOf(Color(0xFF1B2A6B), Color(0xFFB04BD8), Color(0xFFFF8A5B)))),
        contentAlignment = Alignment.Center
    ) { Image(bmp, app.label, Modifier.size(160.dp)) }
}

@Composable
fun Param(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Slider(value, onChange, valueRange = range)
    }
}

fun savePng(ctx: Context, bmp: Bitmap, name: String) {
    val v = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "glass_$name.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GlassIcons")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
    ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    Toast.makeText(ctx, "Saved to Pictures/GlassIcons", Toast.LENGTH_SHORT).show()
}

fun pin(ctx: Context, app: AppItem, bmp: Bitmap) {
    val intent = ctx.packageManager.getLaunchIntentForPackage(app.pkg) ?: return
    if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
        Toast.makeText(ctx, "Your launcher doesn't support pinned shortcuts", Toast.LENGTH_SHORT).show(); return
    }
    val info = ShortcutInfoCompat.Builder(ctx, "glass_${app.pkg}")
        .setShortLabel(app.label)
        .setIcon(IconCompat.createWithBitmap(bmp))
        .setIntent(intent).build()
    ShortcutManagerCompat.requestPinShortcut(ctx, info, null)
}
