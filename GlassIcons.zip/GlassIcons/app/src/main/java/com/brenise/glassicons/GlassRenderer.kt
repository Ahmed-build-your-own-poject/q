package com.brenise.glassicons

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import androidx.core.graphics.ColorUtils

data class AppItem(val pkg: String, val label: String, val icon: Drawable)

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

object GlassRenderer {

    /** Rounded-rect with adjustable corner radius + squircle smoothing. */
    fun shape(s: IconStyle, w: Float): Path {
        val r = s.corner.coerceIn(0f, 0.5f) * w
        val sm = s.smooth.coerceIn(0f, 1f)
        val d = minOf(r * (1 + sm), w / 2)
        val k = d * (0.4477f - 0.2f * sm)
        return Path().apply {
            moveTo(d, 0f); lineTo(w - d, 0f)
            cubicTo(w - k, 0f, w, k, w, d)
            lineTo(w, w - d)
            cubicTo(w, w - k, w - k, w, w - d, w)
            lineTo(d, w)
            cubicTo(k, w, 0f, w - k, 0f, w - d)
            lineTo(0f, d)
            cubicTo(0f, k, k, 0f, d, 0f)
            close()
        }
    }

    fun render(icon: Drawable, s: IconStyle, px: Int = 512): Bitmap {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val size = px.toFloat()
        val path = shape(s, size)
        val white = Color.WHITE
        fun p() = Paint(Paint.ANTI_ALIAS_FLAG)

        // tinted glass body
        c.drawPath(path, p().apply {
            shader = LinearGradient(0f, 0f, 0f, size,
                ColorUtils.setAlphaComponent(s.tint, 170),
                ColorUtils.setAlphaComponent(s.tint, 70), Shader.TileMode.CLAMP)
        })
        c.save(); c.clipPath(path)
        // frost
        c.drawPath(path, p().apply {
            shader = LinearGradient(0f, 0f, size, size,
                ColorUtils.setAlphaComponent(white, (s.frost * 200).toInt()),
                ColorUtils.setAlphaComponent(white, (s.frost * 50).toInt()), Shader.TileMode.CLAMP)
        })
        // specular shine on the top half
        c.drawRect(0f, 0f, size, size * 0.5f, p().apply {
            shader = LinearGradient(0f, 0f, 0f, size * 0.5f,
                ColorUtils.setAlphaComponent(white, (s.shine * 190).toInt()),
                ColorUtils.setAlphaComponent(white, 0), Shader.TileMode.CLAMP)
        })
        // glyph
        val d = (icon.constantState?.newDrawable() ?: icon).mutate()
        val adaptive = d is AdaptiveIconDrawable
        val fg = if (adaptive) (d as AdaptiveIconDrawable).foreground else d
        val inner = size * (1 - 2 * s.padding)
        val side = if (adaptive) inner * 1.5f else inner
        val off = ((size - side) / 2).toInt()
        fg.setBounds(off, off, off + side.toInt(), off + side.toInt())
        fg.draw(c)
        c.restore()
        // glass edge
        c.drawPath(path, p().apply {
            style = Paint.Style.STROKE
            strokeWidth = size * 0.014f
            shader = LinearGradient(0f, 0f, size, size,
                ColorUtils.setAlphaComponent(white, (s.border * 255).toInt()),
                ColorUtils.setAlphaComponent(white, (s.border * 50).toInt()), Shader.TileMode.CLAMP)
        })
        return bmp
    }
}
