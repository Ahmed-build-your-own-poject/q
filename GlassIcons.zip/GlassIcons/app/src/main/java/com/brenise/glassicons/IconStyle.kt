package com.brenise.glassicons

enum class Design(val label: String) { IOS("iOS"), ONEUI("One UI"), CUSTOM("Custom") }

data class IconStyle(
    val design: Design = Design.IOS,
    val corner: Float = 0.225f,   // corner radius as fraction of icon size (0..0.5)
    val smooth: Float = 0.6f,     // squircle smoothing (0 = plain rounded rect, 1 = max)
    val padding: Float = 0.16f,   // space around the glyph
    val frost: Float = 0.35f,     // glass frost amount
    val border: Float = 0.6f,     // edge highlight strength
    val shine: Float = 0.5f,      // top specular shine
    val tint: Int = 0xFF7C9CFF.toInt()
) {
    fun withDesign(d: Design) = when (d) {
        Design.IOS -> copy(design = d, corner = 0.225f, smooth = 0.6f)
        Design.ONEUI -> copy(design = d, corner = 0.32f, smooth = 1f)
        Design.CUSTOM -> copy(design = d)
    }
}
