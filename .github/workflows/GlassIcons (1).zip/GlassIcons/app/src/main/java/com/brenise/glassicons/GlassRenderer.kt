package com.brenise.glassicons

import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.Drawable
import androidx.core.graphics.ColorUtils

data class AppItem(val pkg: String, val label: String, val icon: Drawable)

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

object GlassRenderer {

    /** Rounded-rect with adjustable corner radius + squircle smoothing. */
    fun shape(s: IconStyle, w: Float): Path {
        val r = s.corner.coerceIn(0f, 0.5f) * w
        val sm = s.smooth.coerceIn(0f, 1f)
        val d = minOf(r * (1 + sm), w / 2)
        val k = d * (0.4477f - 0.2f * sm)
        return Path().apply {
            moveTo(d, 0f); lineTo(w - d, 0f)
            cubicTo(w - k, 0f, w, k, w, d)
            lineTo(w, w - d)
            cubicTo(w, w - k, w - k, w, w - d, w)
            lineTo(d, w)
            cubicTo(k, w, 0f, w - k, 0f, w - d)
            lineTo(0f, d)
            cubicTo(0f, k, k, 0f, d, 0f)
            close()
        }
    }

    fun render(icon: Drawable, s: IconStyle, px: Int = 512): Bitmap {
        val bmp = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val size = px.toFloat()
        val path = shape(s, size)
        val white = Color.WHITE
        val gl = s.glass.coerceIn(0f, 1f)
        fun p() = Paint(Paint.ANTI_ALIAS_FLAG)
        fun a(f: Float) = (f.coerceIn(0f, 1f) * 255).toInt()
        fun al(col: Int, f: Float) = ColorUtils.setAlphaComponent(col, a(f))

        // flat body (One UI side of the blend): solid pastel tile
        if (gl < 1f) {
            val top = ColorUtils.blendARGB(s.tint, white, 0.78f)
            val bottom = ColorUtils.blendARGB(s.tint, white, 0.55f)
            c.drawPath(path, p().apply {
                shader = LinearGradient(0f, 0f, 0f, size, al(top, 1 - gl), al(bottom, 1 - gl), Shader.TileMode.CLAMP)
            })
        }
        // glass body (iOS side): translucent tint
        if (gl > 0f) {
            c.drawPath(path, p().apply {
                shader = LinearGradient(0f, 0f, 0f, size, al(s.tint, 0.67f * gl), al(s.tint, 0.27f * gl), Shader.TileMode.CLAMP)
            })
        }
        c.save(); c.clipPath(path)
        // frost
        c.drawPath(path, p().apply {
            shader = LinearGradient(0f, 0f, size, size, al(white, s.frost * 0.78f), al(white, s.frost * 0.2f), Shader.TileMode.CLAMP)
        })
        // specular shine, top half
        c.drawRect(0f, 0f, size, size * 0.5f, p().apply {
            shader = LinearGradient(0f, 0f, 0f, size * 0.5f, al(white, s.shine * 0.75f), al(white, 0f), Shader.TileMode.CLAMP)
        })
        // glass-only: inner rim light + bottom caustic glow
        if (gl > 0f) {
            c.drawPath(path, p().apply {
                style = Paint.Style.STROKE
                strokeWidth = size * 0.07f
                color = al(white, 0.35f * gl)
                maskFilter = BlurMaskFilter(size * 0.03f, BlurMaskFilter.Blur.NORMAL)
            })
            c.drawRect(0f, size * 0.62f, size, size, p().apply {
                shader = LinearGradient(0f, size * 0.62f, 0f, size, al(white, 0f), al(white, 0.28f * gl), Shader.TileMode.CLAMP)
            })
        }
        // glyph, drawn to its own layer so it can cast a soft shadow
        val d = (icon.constantState?.newDrawable() ?: icon).mutate()
        val adaptive = d is AdaptiveIconDrawable
        val fg = if (adaptive) (d as AdaptiveIconDrawable).foreground else d
        val inner = size * (1 - 2 * s.padding)
        val side = if (adaptive) inner * 1.5f else inner
        val off = ((size - side) / 2).toInt()
        fg.setBounds(off, off, off + side.toInt(), off + side.toInt())
        val g = Bitmap.createBitmap(px, px, Bitmap.Config.ARGB_8888)
        fg.draw(Canvas(g))
        if (s.depth > 0f) {
            val blur = Paint().apply { maskFilter = BlurMaskFilter(size * 0.02f, BlurMaskFilter.Blur.NORMAL) }
            val o = IntArray(2)
            val shadow = g.extractAlpha(blur, o)
            c.drawBitmap(shadow, o[0].toFloat(), o[1] + size * 0.018f,
                Paint().apply { color = Color.argb(a(s.depth * 0.45f), 0, 0, 0) })
        }
        c.drawBitmap(g, 0f, 0f, null)
        c.restore()
        // glass edge
        if (s.border > 0f) {
            c.drawPath(path, p().apply {
                style = Paint.Style.STROKE
                strokeWidth = size * 0.014f
                shader = LinearGradient(0f, 0f, size, size, al(white, s.border), al(white, s.border * 0.2f), Shader.TileMode.CLAMP)
            })
        }
        return bmp
    }
}
