package com.brenise.glassicons

enum class Design(val label: String, val blurb: String) {
    IOS("iOS", "Liquid Glass: translucent tint, shine, rim light, floating glyph"),
    ONEUI("One UI", "Soft flat squircle: solid pastel tile, no shine, gentle depth"),
    CUSTOM("Custom", "Mix everything yourself, from flat to full glass")
}

data class IconStyle(
    val design: Design = Design.IOS,
    val corner: Float = 0.225f,   // corner radius as fraction of icon size (0..0.5)
    val smooth: Float = 0.6f,     // squircle smoothing
    val padding: Float = 0.16f,   // space around the glyph
    val glass: Float = 1f,        // 0 = solid flat tile, 1 = translucent glass
    val frost: Float = 0.35f,
    val border: Float = 0.6f,
    val shine: Float = 0.5f,
    val depth: Float = 0.5f,      // glyph drop shadow
    val tint: Int = 0xFF7C9CFF.toInt()
) {
    fun withDesign(d: Design) = when (d) {
        Design.IOS -> copy(design = d, corner = 0.225f, smooth = 0.6f, padding = 0.16f,
            glass = 1f, frost = 0.35f, border = 0.6f, shine = 0.5f, depth = 0.5f)
        Design.ONEUI -> copy(design = d, corner = 0.30f, smooth = 1f, padding = 0.14f,
            glass = 0f, frost = 0f, border = 0f, shine = 0f, depth = 0.25f)
        Design.CUSTOM -> copy(design = d)
    }
}
